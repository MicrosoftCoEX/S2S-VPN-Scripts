﻿#need Azure PSH Provider
#https://azure.microsoft.com/en-us/downloads/
#http://aka.ms/webpi-azps

Get-Module *azure*

#[classic] 
Add-azureaccount 
Get-AzureSubscription 
Select-AzureSubscription -SubscriptionName "MSDN - Demo Subscription"
Get-AzureVM

#[Resource] 
Login-AzureRmAccount
Get-AzureRmSubscription # (to list subsriptions) 
Select-AzureRmSubscription -SubscriptionId Please enter the SubscriptionId 
Get-AzureRmSubscription –SubscriptionName  "Subscription Name" | Select-AzureRmSubscription 
Get-AzureRMVM

