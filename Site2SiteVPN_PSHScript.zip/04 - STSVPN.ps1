﻿#####################
#Provision Network


#create our base variables for our Resource Group 
$rgName="Resource Group Name"
$locName="West Europe"  
$saName="Storage Account name" #must be lower case
$vnetName="Virtual NetName"


#add our local Networksite 
#Name Nickname for our on-premises network 
#NewGatewayIPAddress is the IP address of your on-premises VPN 
#AddressPrefix is your on-premises address space. 
New-AzureRmLocalNetworkGateway -Name xxxOnPremises -ResourceGroupName $rgName -Location $locName -GatewayIpAddress '41.231.8.226' -AddressPrefix '192.168.0.0/24' 


#request a public IP address for the gateway 

$gwpip= New-AzureRmPublicIpAddress -Name xxxgwpip -ResourceGroupName $rgName -Location $locName -AllocationMethod dynamic 

#create the gateway IP addressing configuration 

$vnet = Get-AzureRmVirtualNetwork -Name $vnetName -ResourceGroupName $rgName 
$subnet = Get-AzureRmVirtualNetworkSubnetConfig -Name 'GatewaySubnet' -VirtualNetwork $vnet 
$gwipconfig = New-AzureRmVirtualNetworkGatewayIpConfig -Name xxxgwipconfig1 -SubnetId $subnet.Id -PublicIpAddressId $gwpip.Id  

#create the gateway - may wait a while 

New-AzureRmVirtualNetworkGateway -Name xxxvnetgw1  -ResourceGroupName $rgName -Location $locName -IpConfigurations $gwipconfig -GatewayType Vpn -VpnType RouteBased 

#https://azure.microsoft.com/en-us/documentation/articles/vpn-gateway-create-site-to-site-rm-powershell/#7-configure-your-vpn-device 

#Get the public IP address for the next step of building our connection script for RRAS either via powershell or via the Portal

Get-AzureRmPublicIpAddress -Name xxxgwpip -ResourceGroupName $rgName 


#BUILD our RRAS Configuration 

$gateway1 = Get-AzureRmVirtualNetworkGateway -Name xxxvnetgw1 -ResourceGroupName $rgName 
 
$local = Get-AzureRmLocalNetworkGateway -Name xxxOnPremises -ResourceGroupName $rgName 
 
New-AzureRmVirtualNetworkGatewayConnection -Name xxxToAzureVPN -ResourceGroupName $rgName -Location $locName -VirtualNetworkGateway1 $gateway1 -LocalNetworkGateway2 $local -ConnectionType IPsec -RoutingWeight 10 -SharedKey 'abc123' 

