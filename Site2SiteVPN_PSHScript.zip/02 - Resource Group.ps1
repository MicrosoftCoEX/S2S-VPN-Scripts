﻿
#create our base variables for our Resource Group 
$rgName="RESOURCE GROUP NAME"  
$locName="RSG LOCATION        "  
$saName="Storage ACCOUNT NAME" #must be lower case
$vnetName="VNET NAME" 

New-AzureRmResourceGroup -Name $rgName -Location $locName 

############################################################ 


#Provision Storage and Network 
 

############################################################ 


#Create Storage account for our VM  
#test if our storage group name is globally unique, and if not rename it 

Test-AzureName -Storage $saName 
 
$saType="Premium_LRS" 
 


#Standard_LRS [Locally Redundant], Standard_GRS [Geo Redundant], Standard_RAGRS [Read Access Georedundant], or Premium_LRS [Premium Locally Redundant (SSD)] 
New-AzureRmStorageAccount -Name $saName -ResourceGroupName $rgName –Type $saType -Location $locName 



#Create Networking Components
#It's important to create one subnet named specifically GatewaySubnet. If you name it something else, our connection configuration will fail.  
$Subnet=New-AzureRmVirtualNetworkSubnetConfig -Name Vnet Name -AddressPrefix 10.10.10.0/27 
$GatewaySubnet = New-AzureRmVirtualNetworkSubnetConfig -Name 'GatewaySubnet' -AddressPrefix 10.10.10.32/29 
New-AzureRmVirtualNetwork -Name $vnetName -ResourceGroupName $rgName -Location $locName -AddressPrefix 10.10.10.0/24 -Subnet $Subnet,$GatewaySubnet -DnsServer 10.10.10.4,192.168.0.22 
