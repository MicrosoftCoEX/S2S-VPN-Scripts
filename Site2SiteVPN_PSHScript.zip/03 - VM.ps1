﻿#####################
#Provision VM


#create our base variables for our Resource Group 
$rgName="         "  
$locName="       "  
$saName="            " #must be lower case
$vnetName="         "



#create a list of subnets, our production network will be network 0 

Get-AzureRmVirtualNetwork  -name  Please Place AzureVirtualNetwork Name -ResourceGroupName $rgName | select subnets 
$subnetIndex=2 
$vnet=Get-AzureRmVirtualNetwork -Name uhdrecettevnet -ResourceGroupName $rgName 


#Assign a static IP address to our first VM
#specify a NIC with a static private IP address 

$nicName= "Internal" 
$staticIP="10.70.2.10" 

#add a public IP address via $pip so we can connect to it if we need to
$pip = New-AzureRmPublicIpAddress -Name $nicName -ResourceGroupName $rgName -Location $locName -AllocationMethod Dynamic 
$nic = New-AzureRmNetworkInterface -Name $nicName -ResourceGroupName $rgName -Location $locName -SubnetId $vnet.Subnets[$subnetIndex].Id -PublicIpAddressId $pip.Id -PrivateIpAddress $staticIP 




# don't know what VM sizes we have, so lets take a look 
Get-AzureRmVMSize -Location $locName | Select Name 

#name and size our Domain Controller 
$vmName="POCAZ019910" 
$vmSize="Standard_DS3_v2" 
$vm=New-AzureRmVMConfig -VMName $vmName -VMSize $vmSize 

#want to select a Windows Server SKU That suites you 
Get-AzureRMVMImageSku -Location $locName -Publisher MicrosoftWindowsServer -Offer WindowsServer | Select Skus 

#I've choosen an SKU of ws2k12R2 Datacenter
$pubName="MicrosoftWindowsServer" 
$offerName="WindowsServer" 
$skuName="2012-R2-Datacenter" 


$cred=Get-Credential -Message "DONT FORGET THE USERNAME & PASSWORD !!!!!! Type the name and password of the local administrator account."  
$vm=Set-AzureRmVMOperatingSystem -VM $vm -Windows -ComputerName $vmName -Credential $cred -ProvisionVMAgent -EnableAutoUpdate 
$vm=Set-AzureRmVMSourceImage -VM $vm -PublisherName $pubName -Offer $offerName -Skus $skuName -Version "latest"  
$vm=Add-AzureRmVMNetworkInterface -VM $vm -Id $nic.Id 
$diskName="OSDisk"  
$storageAcc=Get-AzureRmStorageAccount -ResourceGroupName $rgName -Name $saName 
$osDiskUri=$storageAcc.PrimaryEndpoints.Blob.ToString() + "vhds/" + $diskName + ".vhd"  
$vm=Set-AzureRmVMOSDisk -VM $vm -Name $diskName -VhdUri $osDiskUri -CreateOption fromImage  
New-AzureRmVM -ResourceGroupName $rgName -Location $locName -VM $vm 
